const express = require('express');
const app = express();
const port = 30089;
app.use(express.json())

app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});

const {listar} = require('./aluguel/listar');
app.get('/aluguel', listar);

app.use((req, res) => {
    res.status(404).send('Página não encontrada!');
    });